export const properties = {
    missingInfo: "Missing Info:",
    missingName: " [Task Name]",
    missingTime: " [Time Spent]",
    missingDate: " [Date]",
    savedData: "Week with id [0] is saved"
};